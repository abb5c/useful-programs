﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "a" Then
            MsgBox("1")
        End If

        If TextBox1.Text = "b" Then
            MsgBox("2")

        End If
        If TextBox1.Text = "c" Then
            MsgBox("3")

        End If
        If TextBox1.Text = "d" Then
            MsgBox("4")

        End If
        If TextBox1.Text = "e" Then
            MsgBox("5")

        End If
        If TextBox1.Text = "f" Then
            MsgBox("6")
        End If

        If TextBox1.Text = "g" Then
            MsgBox("7")

        End If
        If TextBox1.Text = "h" Then
            MsgBox("8")

        End If
        If TextBox1.Text = "i" Then
            MsgBox("9")

        End If
        If TextBox1.Text = "j" Then
            MsgBox("10")

        End If

        If TextBox1.Text = "k" Then
            MsgBox("11")

        End If
        If TextBox1.Text = "l" Then
            MsgBox("12")

        End If
        If TextBox1.Text = "m" Then
            MsgBox("13")

        End If
        If TextBox1.Text = "n" Then
            MsgBox("14")
        End If

        If TextBox1.Text = "o" Then
            MsgBox("15")

        End If
        If TextBox1.Text = "p" Then
            MsgBox("16")

        End If
        If TextBox1.Text = "q" Then
            MsgBox("17")

        End If
        If TextBox1.Text = "r" Then
            MsgBox("18")

        End If
        If TextBox1.Text = "s" Then
            MsgBox("19")
        End If

        If TextBox1.Text = "t" Then
            MsgBox("20")

        End If
        If TextBox1.Text = "u" Then
            MsgBox("21")

        End If
        If TextBox1.Text = "v" Then
            MsgBox("22")

        End If
        If TextBox1.Text = "w" Then
            MsgBox("23")

        End If

        If TextBox1.Text = "x" Then
            MsgBox("24")

        End If
        If TextBox1.Text = "y" Then
            MsgBox("25")

        End If
        If TextBox1.Text = "z" Then
            MsgBox("26")

        End If
    End Sub
End Class

